function EcNetCardWrapper() {
    this.netCardInstance = null;
    this.version = "1.0.0"
}

let ecNetCard = new EcNetCardWrapper();

/**
 * [网络验证]初始化卡密
 * 提卡网址 [http://uc.ieasyclick.com]
 * 适配版本 EC iOS 中控 6.12.0+
 * @param appId 应用的appId，用户中心后台获取
 * @param appSecret 应用的密钥，用户中心后台获取
 * @return {null|JSON} 返回JSON对象,{"code":0,"msg":"",}
 */
EcNetCardWrapper.prototype.netCardInit = function (appId, appSecret) {
    if (this.netCardInstance == null || this.netCardInstance == undefined) {
        this.loadNetCardPlugin()
    }
    if (this.netCardInstance == null || this.netCardInstance == undefined) {
        return {"code": -1, "msg": "载入失败，无法实例化插件"}
    }
    return this.netCardInstance.init(appId, appSecret);
};

EcNetCardWrapper.prototype.loadNetCardPlugin = function () {
    logd("网络验证插件版本:" + this.version)
    let load = loadDex("netcard.jar")
    if (!load) {
        loge("载入网络验证插件失败")
        return false;
    }
    importClass(com.iec.netcard.JsNetCard)
    this.netCardInstance = new com.iec.netcard.JsNetCard()

};

/**
 * [网络验证]绑定卡密
 * 提卡网址 [http://uc.ieasyclick.com]
 * 适配版本 EC iOS 中控 6.12.0+
 * @param cardNo 卡号，用户中心后台获取
 * @return {null|JSON} 返回JSON对象,{"code":0,"msg":"",}
 */
EcNetCardWrapper.prototype.netCardBind = function (cardNo) {
    if (this.netCardInstance == null || this.netCardInstance == undefined) {
        return {"code": -1, "msg": "无插件实例，请调用初始化函数"}
    }
    let x = this.netCardInstance.bindCard(cardNo, device.getDeviceId(), "")
    if (x == null || x == undefined || x == "") {
        return null;
    }
    return JSON.parse(x);
}

/**
 * [网络验证]解绑卡密
 * 提卡网址 [http://uc.ieasyclick.com]
 * 适配版本 EC iOS 中控 6.12.0+
 * @param cardNo 卡号，用户中心后台获取
 * @param password 解绑密码 ，如果设置过解绑密码 需要填写
 * @return {null|JSON} 返回JSON对象,{"code":0,"msg":"",}
 */
EcNetCardWrapper.prototype.netCardUnbind = function (cardNo, password) {
    if (this.netCardInstance == null || this.netCardInstance == undefined) {
        return {"code": -1, "msg": "无插件实例，请调用初始化函数"}
    }
    let x = this.netCardInstance.unbindCard(device.getDeviceId(), cardNo, password)
    if (x == null || x == undefined || x == "") {
        return null;
    }
    return JSON.parse(x);
}


/**
 * [网络验证-远程变量]获取远程变量
 * 提卡网址 [http://uc.ieasyclick.com]
 * 适配版本 EC iOS 中控 6.12.0+
 * @param key 远程变量名称
 * @return {null|JSON} 返回JSON对象,{"code":0,"msg":""}
 */
EcNetCardWrapper.prototype.netCardGetCloudVar = function (key) {
    if (this.netCardInstance == null || this.netCardInstance == undefined) {
        return {"code": -1, "msg": "无插件实例，请调用初始化函数"}
    }
    let x = this.netCardInstance.getCloudVar(key)
    if (x == null || x == undefined || x == "") {
        return null;
    }
    return JSON.parse(x);
}

/**
 * [网络验证-远程变量]更新远程变量
 * 提卡网址 [http://uc.ieasyclick.com]
 * 适配版本 EC iOS 中控 6.12.0+
 * @param key 远程变量名称
 * @param value 远程变量内容
 * @return {null|JSON} 返回JSON对象,{"code":0,"msg":""}
 */

EcNetCardWrapper.prototype.netCardUpdateCloudVar = function (key, value) {
    let x = this.netCardInstance.updateCloudVar(key, value)
    if (x == null || x == undefined || x == "") {
        return null;
    }
    return JSON.parse(x);
}