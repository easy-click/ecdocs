#!/bin/bash
WORK_DIR= `pwd`
echo `$WORK_DIR`

build_plugin_frame(){
  rm -rf /tmp/derivedDataPath/*
  xcodebuild build -project helloworldplugin.xcodeproj -scheme helloworldplugin -sdk iphoneos -configuration Release -derivedDataPath /tmp/derivedDataPath -allowProvisioningUpdates

  cp -r /tmp/derivedDataPath/Build/Products/Release-iphoneos/helloworldplugin.framework ./

  cd $WORK_DIR
}

build_plugin_frame


