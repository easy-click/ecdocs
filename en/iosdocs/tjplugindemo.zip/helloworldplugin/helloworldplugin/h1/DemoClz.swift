//
//  DemoClz.swift
//  helloworldplugin
//
//  Created by wangbx on 2024/8/5.
//

import Foundation

public class DemoClz{
    
    public func call()->String{
        return "return from demo  class "
    }
    
}
