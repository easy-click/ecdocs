//
//  helloworldplugin.h
//  helloworldplugin
//
//  Created by wangbx on 2024/8/5.
//

#import <Foundation/Foundation.h>

//! Project version number for helloworldplugin.
FOUNDATION_EXPORT double helloworldpluginVersionNumber;

//! Project version string for helloworldplugin.
FOUNDATION_EXPORT const unsigned char helloworldpluginVersionString[];

// In this header, you should import all the public headers of your framework using statements like #import <helloworldplugin/PublicHeader.h>


