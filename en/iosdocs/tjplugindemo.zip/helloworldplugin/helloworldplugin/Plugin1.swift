

import Foundation
import pluginhost
import JavaScriptCore
public class Plugin1 : NSObject, ECPlugin,JSExport{
    public func callMethodAny(_ methodName: String, _ data: Any) -> Any? {
        return nil
    }
    
    public func callMethodStr(_ methodName: String, _ args: String) -> String {
        let c = DemoClz()
        
        return " callMethodStr "+methodName + "  "+args + "   other: "+c.call();
    }
    
    public func callMethodData(_ methodName: String, _ data: Data) -> String {
        let a = String(data: data, encoding: .utf8)
        return " callMethodData " + methodName + "  "+(a ?? "");
    }
    
    public func callMethodReturnData(_ methodName: String, _ data: String) -> Data {
        let a = "callMethodDataReturnData "+methodName;
        return a.data(using: .utf8)!;
    }
    
    public func disposed() {
        print("disposed plugin...")
    }
    
    
    
    public required override init(){
        
    }
    
    
    
    
    
}
