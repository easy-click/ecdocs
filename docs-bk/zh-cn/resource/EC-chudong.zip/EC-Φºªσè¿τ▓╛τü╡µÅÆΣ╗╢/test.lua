

--依赖苏泽库
--EasyClick.startEnv() 是必须要调用一次的
--必须安装ec调试版
--首次启动 会出现ec调试版需要权限的问题
require("EasyClick")
if(EasyClick.startEnv()==false) then
toast("启动 EasyClick 服务失败",1)	
lua_exit()
end
mSleep(3000)
EasyClick.toast("哈哈哈哈哈哈哈哈哈哈")
mSleep(3000)
EasyClick.home()
mSleep(1000)