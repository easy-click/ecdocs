
require("EasyClick")


EasyClick.startEnv()  --调用该命令启动环境

--技术交流Q群: 777164022
--bug修复联系QQ  370606730
--本插件只有节点属性生成和多点触摸和官方文档不一致
--其他命令和参数、 命令类型等 与EasyClick 官方文档完全一致
--官方文档地址  https://easyclick.gitee.io/docs/zh-cn/zk/zk.html

--插件节点操作示例


local node1={}
node1["id"] = "雷电游戏中心"
node1["clz"] = "android.widget.TextView"
node1["index"] = 1
node1["depth"] = 8
EasyClick.click(node)  --点击

--示例2
local node1={}
node1["id"] = "雷电游戏中心"
EasyClick.click(node)  --点击



--==========多点触摸  例子==========
Dim touch1,touch2
--下面3个命令是组合命令 必须按照顺序使用 不使用下面3个命令的 可以自己生成合适的json格式数据
--EasyClick.init_multiTouch_params() 
--EasyClick.add_multiTouch_params  该命令需要调用多次
--touch1=EasyClick.get_multiTouch_params();

--===========================================

EasyClick.init_multiTouch_params() --初始化多点触摸信息 必须调用
--EasyClick.add_multiTouch_params  是生成  {"action": 0, "x": 500, "y": 1200, "pointer": 1, "delay": 1} 格式的数据
EasyClick.add_multiTouch_params( 0, 100, 200, 1, 10 )
EasyClick.add_multiTouch_params( 1, 100, 200, 1, 10)
--此处可以写更多 EasyClick.add_multiTouch_params 1, 100, 200, 1, 10
touch1=EasyClick.get_multiTouch_params()

EasyClick.init_multiTouch_params() --初始化多点触摸信息 必须调用
EasyClick.add_multiTouch_params( 0, 101, 201, 2, 10  ) 
EasyClick.add_multiTouch_params( 1, 101, 201, 2, 10)
touch2=EasyClick.get_multiTouch_params()

EasyClick.multiTouch(touch1,touch2,3000) --调用多点触摸

