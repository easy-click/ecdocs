
local ts = require("ts")--使用扩展库前必须插入这一句
local json = ts.json--使用 JSON 模块前必须插入这一句
EasyClick={}
--QMPlugin=EasyClick
--EasyClick.lastresult 是最后一次返回的结果数组
EasyClick.lastresult=""  --保存的最后的一次结果 后期可能需要这个解析 节点不存在或者服务未启动 都会导致返回假 所以保存这个值
EasyClick.multiTouch_params={}

--===========测试=====


function WriteFile(path, str, mode)
	local iRet, sRet = pcall(function()
			if mode == nil then mode = "w" end
			local f = io.open(path, mode)
			if f == nil then
				return ""
			end
			local ret = f:write(str)
			f:close()
			return ReadFile(path)
		end)
	if iRet == true then
		return sRet
	else
		print(sRet)
		return ""
	end
end


--============================通用=================
function ReadFile(path, isdel)
	local iRet, sRet = pcall(function()
			local f = io.open(path, "r")
			if f == null then
				return ""
			end
			local ret = f:read("*all")
			f:close()
			if isdel then
				os.remove(path)
			end
			return ret
		end)
	if iRet == true then
		return sRet
	else
		print(sRet)
		return ""
	end
end
function EasyClick.decode(data)
	return json.decode(data)
end
function EasyClick.encode(data)
	return json.encode(data)
end

function EasyClick.send(data)
	--通信接口
	data=string.gsub(data, '\\"', '"' )
	
	local savepath="/sdcard/easyclickout.txt"
	local url="http://127.0.0.1:20390/global"
	os.execute(string.format("curl -o %s -d '%s' --connect-timeout 30 -H 'content-type: application/json' '%s'",savepath,data,url))
	local result=ReadFile(savepath, true)
	
	if(string.len(result)>2) then
		--解析返回值

		result=EasyClick.decode(result)
		EasyClick.lastresult=result
		return result.data;
	end
end

--============================节点操作接口====================
--=========日志接口==============

--[[
function EasyClick.toast(msg)
	local params=string.format('{"type":"toast","msg":"%s"}',msg)
	return EasyClick.send(params)

end
function EasyClick.logd(msg)
	local params=string.format('{"type":"logd","msg":"%s"}',msg)
	return EasyClick.send(params)

end
function EasyClick.logi(msg)
	local params=string.format('{"type":"logi","msg":"%s"}',msg)
	return EasyClick.send(params)

end
function EasyClick.logw(msg)
	local params=string.format('{"type":"logw","msg":"%s"}',msg)
	return EasyClick.send(params)

end
function EasyClick.loge(msg)
	local params=string.format('{"type":"loge","msg":"%s"}',msg)
	return EasyClick.send(params)

end
--]]


--[[
1.1. toast 浮层消息
浮层消息
@param msg 消息字符串
--]]
function EasyClick.toast(msg)
	local params={}
	params["type"]="toast"
	params["msg"]=msg
	return EasyClick.send(EasyClick.encode(params))
end


--[[
1.2. logd 调试消息
调试消息
@param msg 消息字符串
--]]
function EasyClick.logd(msg)
	local params={}
	params["type"]="logd"
	params["msg"]=msg
	return EasyClick.send(EasyClick.encode(params))
end


--[[
1.3. logi 信息消息
信息消息
@param msg 消息字符串
--]]
function EasyClick.logi(msg)
	local params={}
	params["type"]="logi"
	params["msg"]=msg
	return EasyClick.send(EasyClick.encode(params))
end


--[[
1.4. logw 警告消息
警告消息
@param msg 消息字符串
--]]
function EasyClick.logw(msg)
	local params={}
	params["type"]="logw"
	params["msg"]=msg
	return EasyClick.send(EasyClick.encode(params))
end


--[[
1.5. loge 错误消息
错误消息
@param msg 消息字符串
--]]
function EasyClick.loge(msg)
	local params={}
	params["type"]="loge"
	params["msg"]=msg
	return EasyClick.send(EasyClick.encode(params))
end

--[[
1.6. setSaveLog 保存日志
设置保存日志到手机操作
@param save 是否保存
@param path 自定义的文件夹
@param size 每个文件分隔的尺寸
@return 保存日志文件的目录
--]]

function EasyClick.setSaveLog(save,path,size)
	local params={}
	params["type"]="setSaveLog"
	params["save"]=save
	params["path"]=path
	params["size"]=size
	return EasyClick.send(EasyClick.encode(params))

end

--[[
1.7. clearLog 清理日志
清除日志
@param lines 整型，要清除的行数，-1 代表全部清除
--]]
function EasyClick.clearLog(lines)
	local params={}
	params["type"]="clearLog"
	params["lines"]=lines
	return EasyClick.send(EasyClick.encode(params))
end


--===================节点服务接口=============

--[[
1.1. exit 退出脚本
退出脚本
--]]
function EasyClick.exit()
	local params={}
	params["type"]="exit"
	return EasyClick.send(EasyClick.encode(params))
end



--[[
1.2. setGestureActionMode 手势模式事件的操作
设置各种手势模式事件的操作类型，默认是异步,目前只对无障碍模式有效
@param mode 1 代表异步，2代表同步
@param bool true代表成功 false代表失败
--]]
function EasyClick.setGestureActionMode(mode,bool)
	local params={}
	params["type"]="setGestureActionMode"
	params["mode"]=mode
	params["bool"]=bool
	return EasyClick.send(EasyClick.encode(params))
end



--[[
1.3. openECSystemSetting 打开EC设置
打开EC设置
--]]
function EasyClick.openECSystemSetting()
	local params={}
	params["type"]="openECSystemSetting"
	return EasyClick.send(EasyClick.encode(params))
end




--[[
1.4. isAccMode 是否无障碍模式
是否无障碍模式
@return 布尔型，true代表是，false代表否
--]]
function EasyClick.isAccMode()
	local params={}
	params["type"]="isAccMode"
	return EasyClick.send(EasyClick.encode(params))
end


--[[
1.5. isAgentMode 是否代理模式
是否代理模式
@return 布尔型，true代表是，false代表否
--]]
function EasyClick.isAgentMode()
	local params={}
	params["type"]="isAgentMode"
	return EasyClick.send(EasyClick.encode(params))
end


--[[
1.6. isServiceOk 节点服务是否正常
节点服务是否正常，不区分运行模式
@return 布尔型，true代表是，false代表否
--]]
function EasyClick.isServiceOk()
	local params={}
	params["type"]="isServiceOk"
	return EasyClick.send(EasyClick.encode(params))
end


--[[
1.7. startEnv 启动环境
启动环境，最好先激活手机，这样会自动启动环境，且免root
@return 布尔型，true代表是，false代表否
--]]
function EasyClick.startEnv()
	local params={}
	params["type"]="startEnv"
	return EasyClick.send(EasyClick.encode(params))
end

--[[
1.8. setECSystemConfig 设置EC系统参数
设置EC系统参数
@param settings JSON内部属性解释:
running_mode : 运行模式 值有 无障碍，代理两种
auto_start_service： 开机自启动 值有 是，否 两种
log_float_window : 日志悬浮窗展示 值有 是，否 两种
ctrl_float_window : 启停控制悬浮窗展示 值有 是，否 两种
@return 布尔型，true代表是，false代表否
--]]
function EasyClick.setECSystemConfig(running_mode,auto_start_service,log_float_window ,ctrl_float_window )
	local params={}
	local settings={}
	settings["running_mode"]=running_mode
	settings["auto_start_service"]=auto_start_service
	settings["log_float_window"]=log_float_window
	settings["ctrl_float_window"]=ctrl_float_window
	params["type"]="setECSystemConfig"
	params["settings"]=settings
	return EasyClick.send(EasyClick.encode(params))

end

--===========选择器构造==========
function EasyClick.create_NodeInfo(id,clz,desc,text)
	--基本节点信息创建
	local info={}
	if(id) then
		info["id"]=id
	end

	if(clz) then
		info["clz"]=clz
	end
	if(desc) then
		info["desc"]=desc
	end
	if(text) then
		info["text"]=text
	end
	--return EasyClick.encode(info)
	return info




end




--=========点击动作接口==============

function EasyClick.clickPoint(x,y)
	local params={}
	params["type"]="clickPoint"
	params["x"]=x
	params["y"]=y
	return EasyClick.send(EasyClick.encode(params))

end

--[[
1.2. longClickPoint 长点击坐标
长点击坐标
@param x x坐标
@param y y坐标
@return 布尔型，true代表成功 false代表失败
--]]
function EasyClick.longClickPoint(x,y)
	local params={}
	params["type"]="longClickPoint"
	params["x"]=x
	params["y"]=y
	return EasyClick.send(EasyClick.encode(params))
end

--selectors 可以用 EasyClick.create_NodeInfo(id,clz,desc,text) 
--[[
1.3. click 选择器点击
选择器点击
@param selectors 选择器数组，更多选择器属性，请查看选择器与节点属性
@return 布尔型，true代表成功 false代表失败
--]]

function EasyClick.click(selectors)
	local params={}
	params["type"]="click"
	params["selectors"]={}
	table.insert(params["selectors"],selectors)
	return EasyClick.send(EasyClick.encode(params))

end


--[[
1.4. clickEx 无指针点击
执行条件：无障碍5.0以上或者手势执行为代理服务
无指针方式点击选择器，节点必须是可点击的才行
@param selectors 选择器对象
@return {boolean|布尔型}
--]]
function EasyClick.clickEx(selectors)
	local params={}
	params["type"]="clickEx"
	params["selectors"]=selectors
	return EasyClick.send(EasyClick.encode(params))
end

--[[
1.5. longClick 长选择器点击
长选择器点击
@param selectors 选择器数组，更多选择器属性，请查看选择器与节点属性
@return 布尔型，true代表成功 false代表失败
--]]
function EasyClick.longClick(selectors)
	local params={}
	params["type"]="longClick"
	params["selectors"]=selectors
	return EasyClick.send(EasyClick.encode(params))
end


--[[
1.6. longClickEx 无指针长点击
执行条件：无障碍5.0以上或者手势执行为代理服务
无指针方式长点击选择器，节点必须是可点击的才行
@param selectors 选择器对象
@return {boolean|布尔型}
--]]
function EasyClick.longClickEx(selectors)
	local params={}
	params["type"]="longClickEx"
	params["selectors"]=selectors
	return EasyClick.send(EasyClick.encode(params))
end

--===============多点触摸动作接口============

--[[
1.1. multiTouch 多点触摸

多点触摸，用法和全局快捷事件-多点触摸相同
@param arrays 多点触摸的数组，请看实例
@param timeout 超时时间，单位毫秒
@return 布尔型，true代表成功 false代表失败
--]]
function EasyClick.init_multiTouch_params()
	--初始化多点参数
	EasyClick.multiTouch_params={}

end
function EasyClick.add_multiTouch_params(action,x,y,pointer,delay)
	--添加多点参数 格式同帮助文档
	local point=string.format('{"action": %d, "x": %d, "y": %d, "pointer": %d, "delay": %d}',action,x,y,pointer,delay)




	table.insert(EasyClick.multiTouch_params,point)

end

function EasyClick.get_multiTouch_params()
	--获取多点参数 这里不区分touch1和touch2
	local result=table.concat(EasyClick.multiTouch_params,",")
	return result
end
--多点触摸的参数要加一个构造函数
function EasyClick.multiTouch(touch1,touch2,timeout)
	--[[
	local params={}
	local arrays={touch1,touch2}
	params["type"]="multiTouch"
	
	params["arrays"]=arrays 
	params["timeout"]=timeout
	--]]
	--这个函数用比较直接的
	data=string.format('{"arrays":[[%s],[%s]],"timeout":%d,"type":"multiTouch"}',touch1,touch2,timeout)
	return EasyClick.send(data)
end


--================滑动动作接口======================

--[[
1.1. swipe 滑动节点
滑动节点
@param selectors 选择器数组，更多选择器属性，请查看选择器与节点属性
@param endX 目标X坐标
@param endY 目标Y坐标
@param duration 动作持续时长，单位毫秒
@return 布尔型，true代表成功 false代表失败
--]]
function EasyClick.swipe(selectors,endX,endY,duration)
	local params={}
	params["type"]="swipe"
	params["selectors"]=selectors
	params["endX"]=endX
	params["endY"]=endY
	params["duration"]=duration
	return EasyClick.send(EasyClick.encode(params))
end



--[[
1.2. swipeToPoint 滑动坐标到目标坐标
滑动坐标到目标坐标
@param startX 起始X坐标
@param startY 起始Y坐标
@param endX 目标X坐标
@param endY 目标Y坐标
@param duration 动作持续时长，单位毫秒
@return 布尔型，true代表成功 false代表失败
--]]
function EasyClick.swipeToPoint(startX,startY,endX,endY,duration)
	local params={}
	params["type"]="swipeToPoint"
	params["startX"]=startX
	params["startY"]=startY
	params["endX"]=endX
	params["endY"]=endY
	params["duration"]=duration
	return EasyClick.send(EasyClick.encode(params))
end


--[[
1.3. isScrollEnd 是否滚动到底部了
是否滚动到底部了，如果查不到元素也会返回false
@param selectors 选择器数组，更多选择器属性，请查看选择器与节点属性
@param direction 滚动方向 UP,DOWN,LEFT,RIGHT
@return 布尔型，true代表成功 false代表失败
--]]
function EasyClick.isScrollEnd(selectors,direction)
	local params={}
	params["type"]="isScrollEnd"
	params["selectors"]=selectors
	params["direction"]=direction
	return EasyClick.send(EasyClick.encode(params))
end


--[[
1.4. scrollForward 无指针向前滚动
执行条件：无障碍5.0以上或者手势执行为代理服务
向前滚动
@param selectors 选择器对象
@return {boolean|布尔型}
--]]
function EasyClick.scrollForward(selectors)
	local params={}
	params["type"]="scrollForward"
	params["selectors"]=selectors
	return EasyClick.send(EasyClick.encode(params))
end


--[[
1.5. scrollBackward 无指针向后滚动
执行条件：无障碍5.0以上或者手势执行为代理服务
向后滚动
@param selectors 选择器对象
@return {boolean|布尔型}
--]]
function EasyClick.scrollBackward(selectors)
	local params={}
	params["type"]="scrollBackward"
	params["selectors"]=selectors
	return EasyClick.send(EasyClick.encode(params))
end


--=========拖动动作接口============


--[[
1.1. drag 从一个坐标到另一个坐标的拖动
从一个坐标到另一个坐标的拖动
@param startX 起始X坐标
@param startY 起始Y坐标
@param endX 目标X坐标
@param endY 目标Y坐标
@param duration 动作持续时长，单位毫秒
@return 布尔型，true代表成功 false代表失败
--]]
function EasyClick.drag(startX,startY,endX,endY,duration)
	local params={}
	params["type"]="drag"
	params["startX"]=startX
	params["startY"]=startY
	params["endX"]=endX
	params["endY"]=endY
	params["duration"]=duration
	return EasyClick.send(EasyClick.encode(params))
end


--[[
1.2. dragTo 拖动节点到目标节点
拖动节点到目标节点
@param selectors 选择器数组，更多选择器属性，请查看选择器与节点属性
@param destObj 目标选择器数组，更多选择器属性，请查看选择器与节点属性
@param duration 动作持续时长，单位毫秒
@return 布尔型，true代表成功 false代表失败
--]]
function EasyClick.dragTo(selectors,destObj,duration)
	local params={}
	params["type"]="dragTo"
	params["selectors"]=selectors
	params["destObj"]=destObj
	params["duration"]=duration
	return EasyClick.send(EasyClick.encode(params))
end


--[[
1.3. dragToPoint 拖动节点到目标坐标
拖动节点到目标坐标
@param selectors 选择器数组，更多选择器属性，请查看选择器与节点属性
@param endX 目标X坐标
@param endY 目标Y坐标
@param duration 动作持续时长，单位毫秒
@return 布尔型，true代表成功 false代表失败
--]]
function EasyClick.dragToPoint(selectors,endX,endY,duration)
	local params={}
	params["type"]="dragToPoint"
	params["selectors"]=selectors
	params["endX"]=endX
	params["endY"]=endY
	params["duration"]=duration
	return EasyClick.send(EasyClick.encode(params))
end

--==================输入动作接口===================

--[[
1.1. currentIsOurIme 当前是否是我们的输入法
当前是否是我们的输入法
@return 布尔型，true代表成功 false代表失败
--]]
function EasyClick.currentIsOurIme()
	local params={}
	params["type"]="currentIsOurIme"
	return EasyClick.send(EasyClick.encode(params))
end


--[[
1.2. inputText 通过选择器输入数据
通过选择器输入数据
@param selectors 选择器数组，更多选择器属性，请查看选择器与节点属性
@param content 数据字符串
@return 布尔型，true代表成功 false代表失败
--]]
function EasyClick.inputText(selectors,content)
	local params={}
	params["type"]="inputText"
	params["selectors"]=selectors
	params["content"]=content
	return EasyClick.send(EasyClick.encode(params))
end


--[[
1.3. imeInputText 通过输入法输入内容
使用输入法输入内容，前提是已经设置本程序的输入法为默认输入法
适合没有节点的情况，例如游戏等
@param selectors 选择器数组，可以为空，如果为空，前提是输入框是聚焦的状态;更多选择器属性，请查看选择器与节点属性
@param content 数据字符串
@return 布尔型，true代表成功 false代表失败
--]]
function EasyClick.imeInputText(selectors,content)
	local params={}
	params["type"]="imeInputText"
	params["selectors"]=selectors
	params["content"]=content
	return EasyClick.send(EasyClick.encode(params))
end


--[[
1.4. pasteText 通过选择器粘贴数据
通过选择器粘贴数据
@param selectors 选择器数组，更多选择器属性，请查看选择器与节点属性
@param content 数据字符串
@return 布尔型，true代表成功 false代表失败
--]]
function EasyClick.pasteText(selectors,content)
	local params={}
	params["type"]="pasteText"
	params["selectors"]=selectors
	params["content"]=content
	return EasyClick.send(EasyClick.encode(params))
end


--[[
1.5. clearTextField 通过选择器清除数据
通过选择器清除数据
@param selectors 选择器数组，更多选择器属性，请查看选择器与节点属性
@return 布尔型，true代表成功 false代表失败
--]]
function EasyClick.clearTextField(selectors)
	local params={}
	params["type"]="clearTextField"
	params["selectors"]=selectors
	return EasyClick.send(EasyClick.encode(params))
end

--================节点操作接口=================

--[[
1.1. has 通过选择器判断元素是否存在
通过选择器判断元素是否存在
@param selectors 选择器数组，更多选择器属性，请查看选择器与节点属性
@return 布尔型，true代表成功 false代表失败
--]]
function EasyClick.has(selectors)
	local params={}
	params["type"]="has"
	params["selectors"]=selectors
	return EasyClick.send(EasyClick.encode(params))
end



--[[
1.2. waitExistActivity 等待activity界面出现
等待activity界面出现
@param activity activity类名
@param timeout 超时时间 单位毫秒
@return 布尔型，true代表成功 false代表失败
--]]
function EasyClick.waitExistActivity(activity,timeout)
	local params={}
	params["type"]="waitExistActivity"
	params["activity"]=activity
	params["timeout"]=timeout
	return EasyClick.send(EasyClick.encode(params))
end


--[[
1.3. waitExistNode 通过选择器判断并等待元素是否存在
通过选择器判断并等待元素是否存在
@param selectors 选择器数组，更多选择器属性，请查看选择器与节点属性
@param timeout 超时时间 单位毫秒
@return 布尔型，true代表成功 false代表失败
--]]
function EasyClick.waitExistNode(selectors,timeout)
	local params={}
	params["type"]="waitExistNode"
	params["selectors"]=selectors
	params["timeout"]=timeout
	return EasyClick.send(EasyClick.encode(params))
end


--[[
1.4. getNodeInfo 获取多个节点信息
获取多个节点信息
@param selectors 选择器数组，更多选择器属性，请查看选择器与节点属性
@param timeout 超时时间 单位毫秒
@return 节点信息集合JSON字符串节点信息属性
--]]
function EasyClick.getNodeInfo(selectors,timeout)
	local params={}
	params["type"]="getNodeInfo"
	params["selectors"]=selectors
	params["timeout"]=timeout
	return EasyClick.send(EasyClick.encode(params))
end


--[[
1.5. getOneNodeInfo 获取单个节点信息
获取单个节点信息
@param selectors 选择器数组，更多选择器属性，请查看选择器与节点属性
@param timeout 超时时间 单位毫秒
@return 单个节点信息JSON字符串节点信息属性
--]]
function EasyClick.getOneNodeInfo(selectors,timeout)
	local params={}
	params["type"]="getOneNodeInfo"
	params["selectors"]=selectors
	params["timeout"]=timeout
	return EasyClick.send(EasyClick.encode(params))
end


--[[
1.6. setFetchNodeMode 设置获取节点的模式
设置获取节点的模式
@param mode 1 是增强型， 2 是快速型，默认是增强型
@param fetchInvisibleNode 是否抓取隐藏的元素，默认不抓取
@param fetchNotImportantNode 是否抓取不重要的元素
@return 布尔型，true代表成功 false代表失败
--]]
function EasyClick.setFetchNodeMode(mode,fetchInvisibleNode,fetchNotImportantNode)
	local params={}
	params["type"]="setFetchNodeMode"
	params["mode"]=mode
	params["fetchInvisibleNode"]=fetchInvisibleNode
	params["fetchNotImportantNode"]=fetchNotImportantNode
	return EasyClick.send(EasyClick.encode(params))
end


--[[
1.7. dumpXml 将元素节点变成XML
将元素节点变成XML
@return 字符串
--]]
function EasyClick.dumpXml()
	local params={}
	params["type"]="dumpXml"
	return EasyClick.send(EasyClick.encode(params))
end

--1.8. lockNode 锁定当前节点
function EasyClick.lockNode()
	local params={}
	params["type"]="lockNode"
	return EasyClick.send(EasyClick.encode(params))
end

--1.9. releaseNode 释放节点的锁
function EasyClick.releaseNode()
	local params={}
	params["type"]="releaseNode"
	return EasyClick.send(EasyClick.encode(params))
end

--2. 单节点连续操作
--以下操作均是建立在取得节点信息后，有节点的nid的时候才能进行，如何取得节点信息请看getOneNodeInfo或者getNodeInfo方法


--[[
2.1. getNodeInfoParent 该节点的父级节点
该节点的父级节点
@param nid nodeinfo的nid值节点信息类
@return 节点信息的JSON字符串
--]]
function EasyClick.getNodeInfoParent(nid)
	local params={}
	params["type"]="getNodeInfoParent"
	params["nid"]=nid
	return EasyClick.send(EasyClick.encode(params))
end


--[[
2.2. getNodeInfoChild 该节点的子节点
该节点的子节点
@param nid nodeinfo的nid值节点信息类
@param index 节点所有 从0开始
@return 节点信息的JSON字符串
--]]
function EasyClick.getNodeInfoChild(nid,index)
	local params={}
	params["type"]="getNodeInfoChild"
	params["nid"]=nid
	params["index"]=index
	return EasyClick.send(EasyClick.encode(params))
end


--[[
2.3. getNodeInfoAllChildren 该节点的所有子节点
该节点的所有子节点
@param nid nodeinfo的nid值节点信息类
@return 节点信息数组的JSON字符串
--]]
function EasyClick.getNodeInfoAllChildren(nid)
	local params={}
	params["type"]="getNodeInfoAllChildren"
	params["nid"]=nid
	return EasyClick.send(EasyClick.encode(params))
end


--[[
2.4. getPreviousSiblingNodeInfo 前面的兄弟节点
前面的兄弟节点
@param nid nodeinfo的nid值节点信息类
@return 节点信息数组的JSON字符串
--]]
function EasyClick.getPreviousSiblingNodeInfo(nid)
	local params={}
	params["type"]="getPreviousSiblingNodeInfo"
	params["nid"]=nid
	return EasyClick.send(EasyClick.encode(params))
end


--[[
2.5. getNextSiblingNodeInfo 后面的兄弟节点
后面的兄弟节点
@param nid nodeinfo的nid值节点信息类
@return 节点信息数组的JSON字符串
--]]
function EasyClick.getNextSiblingNodeInfo(nid)
	local params={}
	params["type"]="getNextSiblingNodeInfo"
	params["nid"]=nid
	return EasyClick.send(EasyClick.encode(params))
end


--[[
2.6. getSiblingNodeInfo 所有兄弟节点
所有兄弟节点
@param nid nodeinfo的nid值节点信息类

@return 节点信息数组的JSON字符串
--]]
function EasyClick.getSiblingNodeInfo(nid)
	local params={}
	params["type"]="getSiblingNodeInfo"
	params["nid"]=nid
	return EasyClick.send(EasyClick.encode(params))
end


--[[
2.7. inputTextNodeInfo 节点输入
节点输入
@param nid nodeinfo的nid值节点信息类
@param content 要输入的内容
@return 布尔型 true 代表保存，false代表不保存
--]]
function EasyClick.inputTextNodeInfo(nid,content)
	local params={}
	params["type"]="inputTextNodeInfo"
	params["nid"]=nid
	params["content"]=content
	return EasyClick.send(EasyClick.encode(params))
end


--[[
2.8. pasteTextNodeInfo 节点粘贴输入
节点粘贴输入
@param nid nodeinfo的nid值节点信息类
@param content 要输入的内容
@return 布尔型 true 代表成功，false代表失败
--]]
function EasyClick.pasteTextNodeInfo(nid,content)
	local params={}
	params["type"]="pasteTextNodeInfo"
	params["nid"]=nid
	params["content"]=content
	return EasyClick.send(EasyClick.encode(params))
end


--[[
2.9. imeInputTextNodeInfo 节点输入法输入
节点输入法输入
@param nid ,可以为空，但是控件提前是聚焦状态 nodeinfo的nid值节点信息类
@param content 要输入的内容
@return 布尔型 true 代表成功，false代表失败
--]]
function EasyClick.imeInputTextNodeInfo(nid,content)
	local params={}
	params["type"]="imeInputTextNodeInfo"
	params["nid"]=nid
	params["content"]=content
	return EasyClick.send(EasyClick.encode(params))
end


--[[
2.10. clearTextNodeInfo 清除节点数据
清除节点数据
@param nid nodeinfo的nid值节点信息类
@return 布尔型 true 代表成功，false代表失败
--]]
function EasyClick.clearTextNodeInfo(nid)
	local params={}
	params["type"]="clearTextNodeInfo"
	params["nid"]=nid
	return EasyClick.send(EasyClick.encode(params))
end


--[[
2.11. refreshNodeInfo 刷新节点数据
刷新节点数据
@param nid nodeinfo的nid值节点信息类
@return 布尔型 true 代表成功，false代表失败
--]]
function EasyClick.refreshNodeInfo(nid)
	local params={}
	params["type"]="refreshNodeInfo"
	params["nid"]=nid
	return EasyClick.send(EasyClick.encode(params))
end


--[[
2.12. isValidNodeInfo 节点是否有效
节点是否有效
@param nid nodeinfo的nid值节点信息类
@return 布尔型 true 代表成功，false代表失败
--]]
function EasyClick.isValidNodeInfo(nid)
	local params={}
	params["type"]="isValidNodeInfo"
	params["nid"]=nid
	return EasyClick.send(EasyClick.encode(params))
end


--[[
2.15. clickNodeInfoEx 无指针方式点击
执行条件：无障碍5.0以上或者手势执行为代理服务
无指针方式点击选择器，节点必须是可点击的才行
@param nid nodeinfo的nid值节点信息类
布尔型 true 代表成功，false代表失败
--]]
function EasyClick.clickNodeInfoEx(nid)
	local params={}
	params["type"]="clickNodeInfoEx"
	params["nid"]=nid
	return EasyClick.send(EasyClick.encode(params))
end


--[[
2.16. longClickNodeInfoEx 无指针方式长点击
执行条件：无障碍5.0以上或者手势执行为代理服务
无指针方式长点击选择器，节点必须是可点击的才行
@param nid nodeinfo的nid值节点信息类
布尔型 true 代表成功，false代表失败
--]]
function EasyClick.longClickNodeInfoEx(nid)
	local params={}
	params["type"]="longClickNodeInfoEx"
	params["nid"]=nid
	return EasyClick.send(EasyClick.encode(params))
end


--[[
2.17. scrollForwardNodeInfo 向前滚动
执行条件：无障碍5.0以上或者手势执行为代理服务
向前滚动
@param nid nodeinfo的nid值节点信息类
@return {boolean|布尔型}
--]]
function EasyClick.scrollForwardNodeInfo(nid)
	local params={}
	params["type"]="scrollForwardNodeInfo"
	params["nid"]=nid
	return EasyClick.send(EasyClick.encode(params))
end



--[[
2.18. scrollBackwardNodeInfo 向后滚动
执行条件：无障碍5.0以上或者手势执行为代理服务
向后滚动
@param nid nodeinfo的nid值节点信息类
@return {boolean|布尔型}
--]]
function EasyClick.scrollBackwardNodeInfo(nid)
	local params={}
	params["type"]="scrollBackwardNodeInfo"
	params["nid"]=nid
	return EasyClick.send(EasyClick.encode(params))
end


--[[
2.19. getOneNodeInfoForNode 取得子节点下面的某个节点
取得子节点下面的某个节点
@param nid nodeinfo的nid值节点信息类
@param selectors 选择器数组，更多选择器属性，请查看选择器与节点属性
@param timeout 超时时间 单位毫秒
@return 单个节点信息JSON字符串节点信息属性
--]]
function EasyClick.getOneNodeInfoForNode(nid,selectors,timeout)
	local params={}
	params["type"]="getOneNodeInfoForNode"
	params["nid"]=nid
	params["selectors"]=selectors
	params["timeout"]=timeout
	return EasyClick.send(EasyClick.encode(params))
end


--[[
2.20. getNodeInfoForNode 取得子节点下面的所有节点
取得子节点下面的所有节点
@param nid nodeinfo的nid值节点信息类
@param selectors 选择器数组，更多选择器属性，请查看选择器与节点属性
@param timeout 超时时间 单位毫秒
@return 节点信息集合JSON字符串节点信息属性
--]]
function EasyClick.getNodeInfoForNode(nid,selectors,timeout)
	local params={}
	params["type"]="getNodeInfoForNode"
	params["nid"]=nid
	params["selectors"]=selectors
	params["timeout"]=timeout
	return EasyClick.send(EasyClick.encode(params))
end

--===============系统按键接口===============

--[[
1.1. power
执行条件：无障碍5.0以上或者手势执行为代理服务
模拟电源按键，无障碍是电源对话框，代理模式是电源键按下
@return {null|布尔型}
--]]
function EasyClick.power()
	local params={}
	params["type"]=""
	return EasyClick.send(EasyClick.encode(params))
end


--[[
1.2. home 返回桌面
返回桌面
@return 布尔型
--]]
function EasyClick.home()
	local params={}
	params["type"]="home"
	return EasyClick.send(EasyClick.encode(params))
end


--[[
1.3. back 返回
返回
@return 布尔型
--]]
function EasyClick.back()
	local params={}
	params["type"]="back"
	return EasyClick.send(EasyClick.encode(params))
end


--[[
1.4. openNotification 打开通知栏
打开通知栏
@return 布尔型
--]]
function EasyClick.openNotification()
	local params={}
	params["type"]="openNotification"
	return EasyClick.send(EasyClick.encode(params))
end


--[[
1.5. openQuickSettings 打开快速设置
打开快速设置
@return 布尔型
--]]
function EasyClick.openQuickSettings()
	local params={}
	params["type"]="openQuickSettings"
	return EasyClick.send(EasyClick.encode(params))
end


--[[
1.6. recentApps 最近APP任务按键
最近APP任务按键
@return 布尔型
--]]
function EasyClick.recentApps()
	local params={}
	params["type"]="recentApps"
	return EasyClick.send(EasyClick.encode(params))
end



--[[
1.7. getRunningPkg 取得当前运行的App包名
取得当前运行的App包名
@return 字符串
--]]
function EasyClick.getRunningPkg()
	local params={}
	params["type"]="getRunningPkg"
	return EasyClick.send(EasyClick.encode(params))
end


--[[
1.8. getRunningActivity 取得当前运行的Activity类名
取得当前运行的Activity类名

@return 字符串
--]]
function EasyClick.getRunningActivity()
	local params={}
	params["type"]="getRunningActivity"
	return EasyClick.send(EasyClick.encode(params))
end

--==================通知栏接口==============

--[[
1.1. hasNotificationPermission 检查是否含有状态栏监听权限
检查是否含有状态栏监听权限
@return 布尔型
--]]
function EasyClick.hasNotificationPermission()
	local params={}
	params["type"]="hasNotificationPermission"
	return EasyClick.send(EasyClick.encode(params))
end



--[[
1.2. requestNotificationPermission 请求监听状态栏的权限
请求监听状态栏的权限
@param timeout 超时时间，单位毫秒
@return 布尔型
--]]
function EasyClick.requestNotificationPermission(timeout)
	local params={}
	params["type"]="requestNotificationPermission"
	params["timeout"]=timeout
	return EasyClick.send(EasyClick.encode(params))
end




--[[
1.3. getLastNotification 获取最近通知栏对象
获取最近通知栏对象
@param pkg 指定包名
@param size 指定获取的条数
@return JSON数组字符串，请参考获取通知
--]]
function EasyClick.getLastNotification(pkg,size)
	local params={}
	params["type"]="getLastNotification"
	params["pkg"]=pkg
	params["size"]=size
	return EasyClick.send(EasyClick.encode(params))
end


--[[
1.4. shotNotification 将通知发射处理，相当于点击了通知栏
将通知发射处理，相当于点击了通知栏
@param seqId getLastNotification方法获取通知栏数据的seqId
@return 布尔型
--]]
function EasyClick.shotNotification(seqId)
	local params={}
	params["type"]="shotNotification"
	params["seqId"]=seqId
	return EasyClick.send(EasyClick.encode(params))
end


--[[
1.5. cancelNotification 将通知进行取消操作
将通知进行取消操作
@param seqId getLastNotification方法获取通知栏数据的seqId
@return 布尔型
--]]
function EasyClick.cancelNotification(seqId)
	local params={}
	params["type"]="cancelNotification"
	params["seqId"]=seqId
	return EasyClick.send(EasyClick.encode(params))
end


--[[
1.6. ignoreNotification 忽略通知
忽略通知，从缓存队列移除，下次将不会获取
@param seqId getLastNotification方法获取通知栏数据的seqId
@return 布尔型
--]]
function EasyClick.ignoreNotification(seqId)
	local params={}
	params["type"]="ignoreNotification"
	params["seqId"]=seqId
	return EasyClick.send(EasyClick.encode(params))
end


--[[
1.7. getLastToast 获取toast数据
获取toast数据

@param pkg 指定包名

@param size 指定获取的条数
@return JSON数组字符串，请参考获取Toast
--]]
function EasyClick.getLastToast(pkg,size)
	local params={}
	params["type"]="getLastToast"
	params["pkg"]=pkg
	params["size"]=size
	return EasyClick.send(EasyClick.encode(params))
end

--==========悬浮窗接口=================

--[[
1.1. hasFloatViewPermission 检查是否含有浮窗权限
检查是否含有浮窗权限

@return 布尔型
--]]
function EasyClick.hasFloatViewPermission()
	local params={}
	params["type"]="hasFloatViewPermission"
	return EasyClick.send(EasyClick.encode(params))
end


--[[
1.2. requestFloatViewPermission 请求展示浮窗的权限
请求展示浮窗的权限
@param timeout 超时时间，单位毫秒
@return 布尔型
--]]
function EasyClick.requestFloatViewPermission(timeout)
	local params={}
	params["type"]="requestFloatViewPermission"
	params["timeout"]=timeout
	return EasyClick.send(EasyClick.encode(params))
end


--[[
1.3. showLogWindow 展示日志浮窗
展示日志浮窗
@return 布尔型
--]]
function EasyClick.showLogWindow()
	local params={}
	params["type"]="showLogWindow"
	return EasyClick.send(EasyClick.encode(params))
end


--[[
1.4. closeLogWindow 关闭日志浮窗
关闭日志浮窗
@return 布尔型 true 代表保存，false代表不保存
--]]
function EasyClick.closeLogWindow()
	local params={}
	params["type"]="closeLogWindow"
	return EasyClick.send(EasyClick.encode(params))
end


--[[
1.5. setLogViewSizeEx 设置日志窗口大小
设置日志窗口大小扩展函数
@param map 例如
{
"x":100,
"y":100,
"w":100,
"h":200,
"textSize":12,
"backgroundColor":"#ffffff",
"title":"我是日志",
"showTitle":true
}
解释：
x: 起始X位置
y: 起始Y位置
w:宽度 h* :高度
textSize:日志的字体大小
backgroundColor:背景颜色，例如#336699
title:日志框标题
showTitle：是否显示标题
@return bool true代表成功，false代表失败
--]]
function EasyClick.setLogViewSizeEx(x,y,w,h,textSize,backgroundColor,title,showTitle)
	local params={}
	local map={}
	map["x"]=x
	map["y"]=y
	map["w"]=w
	map["h"]=h
	map["textSize"]=textSize
	map["backgroundColor"]=backgroundColor
	map["title"]=title
	map["showTitle"]=showTitle
	params["type"]="setLogViewSizeEx"
	params["map"]=map
	return EasyClick.send(EasyClick.encode(params))
end


--[[
1.6. setLogText 展示消息到悬浮窗日志
展示消息到悬浮窗日志中
@param msg 消息
@return 布尔型
--]]
function EasyClick.setLogText(msg)
	local params={}
	params["type"]="setLogText"
	params["msg"]=msg
	return EasyClick.send(EasyClick.encode(params))
end

--[[
1.7. setAllLogEnd 结束所有日志展示
结束所有日志展示，恢复悬浮窗可拖动
@return 布尔型
--]]
function EasyClick.setAllLogEnd()
	local params={}
	params["type"]="setAllLogEnd"
	return EasyClick.send(EasyClick.encode(params))
end


--===================代理事件接口==========

--[[
1.1. setCurrentIme 设置我们的输入法
设置当前的输入法，用于输入数据
@return {boolean|布尔型}
--]]
function EasyClick.setCurrentIme()
	local params={}
	params["type"]="setCurrentIme"
	return EasyClick.send(EasyClick.encode(params))
end


--[[
1.2. restoreIme 恢复输入法
恢复到之前的输入法
@return {boolean|布尔型}
--]]
function EasyClick.restoreIme()
	local params={}
	params["type"]="restoreIme"
	return EasyClick.send(EasyClick.encode(params))
end


--[[
1.3. inputEvent 执行输入事件
执行输入事件
@param action 动作，请看类: MotionEvent.ACTION_*
@param x x坐标
@param y y坐标
@param metaState 控制按键，比如说shift键，alt键，ctrl键等控制键, 0或者 1 any meta info
@return 布尔型 true 代表成功 false代表失败
--]]
function EasyClick.inputEvent(action,x,y,metaState)
	local params={}
	params["type"]="inputEvent"
	params["action"]=action
	params["x"]=x
	params["y"]=y
	params["metaState"]=metaState
	return EasyClick.send(EasyClick.encode(params))
end


--[[
1.4. touchDown 按下事件
执行按下输入事件
@param x x坐标
@param y y坐标
@return 布尔型 true 代表成功 false代表失败
--]]
function EasyClick.touchDown(x,y)
	local params={}
	params["type"]="touchDown"
	params["x"]=x
	params["y"]=y
	return EasyClick.send(EasyClick.encode(params))
end



--[[
1.5. touchMove 移动事件
执行移动输入事件
@param x x坐标
@param y y坐标
@return 布尔型 true 代表成功 false代表失败
--]]
function EasyClick.touchMove(x,y)
	local params={}
	params["type"]="touchMove"
	params["x"]=x
	params["y"]=y
	return EasyClick.send(EasyClick.encode(params))
end


--[[
1.6. touchUp 弹起输事件
执行弹起输入事件
@param x x坐标
@param y y坐标
@return 布尔型 true 代表成功 false代表失败
--]]
function EasyClick.touchUp(x,y)
	local params={}
	params["type"]="touchUp"
	params["x"]=x
	params["y"]=y
	return EasyClick.send(EasyClick.encode(params))
end


--[[
1.7. pressKey 模拟按键
模拟按键,例如home back等
@param key 对应的值分别为 home, back, left, right, up, down, center, menu, search, enter, delete(or del), recent(recent apps), volume_up, volume_down, volume_mute, camera, power *@return 布尔型 true 成功, false 失败
--]]
function EasyClick.pressKey(key)
	local params={}
	params["type"]="pressKey"
	params["key"]=key
	return EasyClick.send(EasyClick.encode(params))
end


--[[
1.8. pressKeyCode 模拟键盘输入
模拟键盘输入
@param keyCode 键盘的key，参见KeyEvent.KEYCODE_*
@return 布尔型 true 代表成功，false 代表失败
--]]
function EasyClick.pressKeyCode(keyCode)
	local params={}
	params["type"]="pressKeyCode"
	params["keyCode"]=keyCode
	return EasyClick.send(EasyClick.encode(params))
end


--[[
1.9. pressKeyCodeWithMetaState 模拟键盘输入
模拟键盘输入
@param keyCode keyCode 键盘的key，参见KeyEvent.KEYCODE_*
@param metaState metaState 控制按键，比如说shift键，alt键，ctrl键等控制键, 0或者 1
@return 布尔型 true 代表成功，false 代表失败。
--]]
function EasyClick.pressKeyCodeWithMetaState(keyCode,metaState)
	local params={}
	params["type"]="pressKeyCodeWithMetaState"
	params["keyCode"]=keyCode
	params["metaState"]=metaState
	return EasyClick.send(EasyClick.encode(params))
end


--[[
1.10. menu 打开菜单
打开菜单
@return {null|布尔型}
--]]
function EasyClick.menu()
	local params={}
	params["type"]="menu"
	return EasyClick.send(EasyClick.encode(params))
end


--[[
1.11. enter Enter键
Enter键
@return {null|布尔型}
--]]
function EasyClick.enter()
	local params={}
	params["type"]="enter"
	return EasyClick.send(EasyClick.encode(params))
end


--[[
1.12. delete 删除键
删除键
@return {null|布尔型}
--]]
function EasyClick.delete()
	local params={}
	params["type"]="delete"
	return EasyClick.send(EasyClick.encode(params))
end


--[[
1.13. closeScreen 关闭屏幕，省点模式
关闭屏幕，屏幕不亮，但是依然可以自动点击
@return 布尔型 true 成功，false 失败
--]]
function EasyClick.closeScreen()
	local params={}
	params["type"]="closeScreen"
	return EasyClick.send(EasyClick.encode(params))
end


--[[
1.14. lightScreen 点亮屏幕
点亮屏幕，和closeScreen相反的动作
@return 布尔型 true 成功，false 失败
--]]
function EasyClick.lightScreen()
	local params={}
	params["type"]="lightScreen"
	return EasyClick.send(EasyClick.encode(params))
end

--===================shell命令模块================


--[[
1.1. installApp 安装 apk
安装 apk
@param path 应用程序的包名
@return true 代表成功，false 代表失败
--]]
function EasyClick.installApp(path)
	local params={}
	params["type"]="installApp"
	params["path"]=path
	return EasyClick.send(EasyClick.encode(params))
end


--[[
1.2. uninstallApp 卸载应用程序
卸载应用程序
@param packageName 应用程序的包名
@return true 代表成功，false 代表失败
--]]
function EasyClick.uninstallApp(packageName)
	local params={}
	params["type"]="uninstallApp"
	params["packageName"]=packageName
	return EasyClick.send(EasyClick.encode(params))
end


--[[
1.3. stopApp 停止正在执行的应用
停止正在执行的应用
@param packageName 应用程序的包名
@return true 代表成功，false 代表失败
--]]
function EasyClick.stopApp(packageName)
	local params={}
	params["type"]="stopApp"
	params["packageName"]=packageName
	return EasyClick.send(EasyClick.encode(params))
end


--[[
1.4. execCommand 执行Shell命令
执行Shell命令
@param command 命令，例如安装App ： pm install /sdcard/app.apk
@return 命令执行后返回的字符串结果
--]]
function EasyClick.execCommand(command)
	local params={}
	params["type"]="execCommand"
	params["command"]=command
	return EasyClick.send(EasyClick.encode(params))
end



