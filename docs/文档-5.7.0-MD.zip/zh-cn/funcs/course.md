# 教程
- [B站教程](https://search.bilibili.com/all?keyword=easyclick)
- [svgxf 视频教程](https://space.bilibili.com/215876102?from=search&seid=2396036071280041367)
- [李大帅 系列视频教程](https://www.bilibili.com/video/BV1Z5411s7Wi)
- [野马先生 视频教程](https://space.bilibili.com/362794941?spm_id_from=333.788.b_765f7570696e666f.2)
