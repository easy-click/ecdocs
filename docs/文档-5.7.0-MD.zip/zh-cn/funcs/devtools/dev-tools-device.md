
# 设备相关

- 菜单栏-EasyClick开发工具-设备连接

## 设备连接
### USB连接
<br/>
<img src='zh-cn/images/getstart-5.jpg' width='300' >

### WIFI连接
- WIFI连接是指需要再手机上开启无线调试模式，
- 点击wifi连接，然后输入手机ip地址即可
- 教程: https://www.jianshu.com/p/a9543f2e89de
### 二维码安装

- 如果部分手机无法安装上EC调试版程序，可以使用扫码方式安装

## 设备激活
- 菜单栏-EasyClick开发工具-激活设备
- 激活设备实现免root运行脚本
- 激活设备可以实现自动开启无障碍，无需手动开启



