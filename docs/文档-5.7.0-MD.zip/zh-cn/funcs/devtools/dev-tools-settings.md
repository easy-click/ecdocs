
# 设置相关
## 设置
- 菜单栏-EasyClick开发工具-EasyClick设置
- 设置包括了和屏幕映射相关的属性
<br/>
<img src='zh-cn/images/settings-1.jpg' width='300' >

