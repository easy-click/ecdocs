
# 屏幕相关
- 菜单栏-EasyClick开发工具-节点抓取
## 节点抓取
- 点击节点抓取按钮，可以获取当前的屏幕元素
- 可以在抓取的屏幕上进行点击，选择元素
- 可以在节点属性窗口，复制节点的值
<br/>
<img src='zh-cn/images/node-1.jpg' width='300' >

## 同屏映射
 
 - 点击屏幕映射按钮，可以连接到当前的设备屏幕，实时预览和操作
 - 如果窗口太小，可以点击右上方的三点按钮，使得窗口进行浮动起来
 <br/>
 <img src='zh-cn/images/screen-1.jpg' width='300' >
 <br/>
 <img src='zh-cn/images/screen-2.jpg' width='300' >

 
## 找色找图操作
- 点击节点抓取按钮，可以获取当前的屏幕元素
- 在图片上点击右键，选择图色模式
- 在图片上想要的区域，拖动出一个矩形框
- 点击右键选择 取色，然后设置想要取得色块的矩阵大小，点击确定，然后根据提示生成代码即可
- 找图：直接选择找图菜单，将图片保存到工程目录下的res文件夹中

 <br/>
 <img src='zh-cn/images/imagecolor-1.jpg' width='300' >
 <br/>
 <img src='zh-cn/images/imagecolor-2.png' width='300' >

