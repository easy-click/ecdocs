# 开发工具
- [百度网盘下载](https://pan.baidu.com/s/124sTYQAZkedgfnTv3iFTZg) 提取码：7bhy
- [天翼云下载](https://cloud.189.cn/t/UbAjqanEzeMz) 密码：nup3
- QQ群下载：777164022
- 下载idea开发工具，文件以idea-xxx开头的，也可以自行到idea官网下载
- IDEA官网下载地址
    - 网页地址：https://www.jetbrains.com/idea/download/other.html
        - 商业版本JS智能提示：2019.3.4 for Windows (exe) https://download.jetbrains.com/idea/ideaIU-2019.3.4.exe
        - 社区版本(免费)：2019.3.4 for Windows (exe) https://download.jetbrains.com/idea/ideaIC-2019.3.4.exe
        

# 源码类库区

- [Github仓库](https://github.com/easy-click/easyclick-libs)

        
# 触动、按键插件
 
- [按键-EC插件下载](/zh-cn/resource/EC-anjian.zip)

- [触动-EC插件下载](/zh-cn/resource/EC-chudong.zip) 
