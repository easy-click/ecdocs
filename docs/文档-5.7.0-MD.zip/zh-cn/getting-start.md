# 下载开发工具
- [百度网盘下载](https://pan.baidu.com/s/124sTYQAZkedgfnTv3iFTZg) 提取码：7bhy
- [天翼云下载](https://cloud.189.cn/t/UbAjqanEzeMz) 密码：nup3
- QQ群下载：777164022
- 下载idea开发工具，文件以idea-xxx开头的，也可以自行到idea官网下载

- IDEA官网下载地址
    - 网页地址：https://www.jetbrains.com/idea/download/other.html
        - 商业版本JS智能提示：2019.3.4 for Windows (exe) https://download.jetbrains.com/idea/ideaIU-2019.3.4.exe
        - 社区版本(免费)：2019.3.4 for Windows (exe) https://download.jetbrains.com/idea/ideaIC-2019.3.4.exe
    
- 安装后，打开bin/idea64.exe文件开始运行
    <br/>
    <img src='zh-cn/images/getstart-1.jpg'>
    
- 下载EasyClick最新版本的IDEA插件，并按照到IDEA中，安装教程：https://blog.csdn.net/qq_35246620/article/details/78289074

# 创建工程
<img src='zh-cn/images/getstart-2.jpg' width='300'>
<br/>
<img src='zh-cn/images/getstart-3.jpg' width='300' >
<br/>
<img src='zh-cn/images/getstart-4.jpg' width='300' >
<br/>
创建成功
<br/>
<img src='zh-cn/images/project-end.jpg' width='300' >


# 连接设备
- 点击菜单 'EasyClick开发工具' - '设备连接' 选择任意一个连接方式
<img src='zh-cn/images/getstart-5.jpg' width='300'>

# 运行程序
- 预览UI
<br/>
<img src='zh-cn/images/getstart-6.jpg' width='200'>
<br/>
- 运行工程，如果运行失败提示无权限，可以点击菜单 'EasyClick开发工具' - '激活设备'
<br/>
<img src='zh-cn/images/getstart-7.jpg' width='200'>
