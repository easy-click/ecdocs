
# EasyClick 易点自动化

> 一个免ROOT功能强大的自动化测试软件

* 免ROOT，支持无障碍，自行构建自动化环境
* 支持图色查找，OpenCV自带并集成
* 支持安卓5.0 ~ 10

[GitHub](https://github.com/easy-click/easyclick-libs)
[开始](README)